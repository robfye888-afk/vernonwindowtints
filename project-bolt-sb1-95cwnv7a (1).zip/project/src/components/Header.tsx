import { Phone, Menu, X } from 'lucide-react';
import { useState } from 'react';

interface HeaderProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

export default function Header({ currentPage, onNavigate }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'services', label: 'Services' },
    { id: 'about', label: 'About' },
    { id: 'testimonials', label: 'Testimonials' },
    { id: 'contact', label: 'Contact' },
  ];

  return (
    <header className="bg-[#001F3F] text-white sticky top-0 z-50 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => onNavigate('home')}>
            <div className="bg-[#FF6600] p-2 rounded-lg">
              <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24">
                <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14z"/>
              </svg>
            </div>
            <div>
              <h1 className="text-xl font-bold">Vernon Window Tint</h1>
              <p className="text-xs text-gray-300">Professional Tinting Services</p>
            </div>
          </div>

          <nav className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={`font-medium hover:text-[#FF6600] transition-colors ${
                  currentPage === item.id ? 'text-[#FF6600]' : ''
                }`}
              >
                {item.label}
              </button>
            ))}
            <a
              href="tel:3238722181"
              className="flex items-center space-x-2 bg-[#FF6600] hover:bg-[#FF7722] px-4 py-2 rounded-lg font-semibold transition-colors"
            >
              <Phone className="w-4 h-4" />
              <span>(323) 872-2181</span>
            </a>
          </nav>

          <button
            className="md:hidden text-white"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {mobileMenuOpen && (
          <nav className="md:hidden pb-4 space-y-2">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  onNavigate(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`block w-full text-left py-2 px-4 rounded hover:bg-[#003366] transition-colors ${
                  currentPage === item.id ? 'bg-[#003366] text-[#FF6600]' : ''
                }`}
              >
                {item.label}
              </button>
            ))}
            <a
              href="tel:3238722181"
              className="flex items-center justify-center space-x-2 bg-[#FF6600] hover:bg-[#FF7722] px-4 py-3 rounded-lg font-semibold transition-colors mt-2"
            >
              <Phone className="w-4 h-4" />
              <span>(323) 872-2181</span>
            </a>
          </nav>
        )}
      </div>
    </header>
  );
}
