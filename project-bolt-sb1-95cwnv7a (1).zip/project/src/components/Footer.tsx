import { Phone, MapPin, Clock, Facebook } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-[#001F3F] text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4 text-[#FF6600]">Contact Us</h3>
            <div className="space-y-3">
              <a href="tel:3238722181" className="flex items-center space-x-3 hover:text-[#FF6600] transition-colors">
                <Phone className="w-5 h-5" />
                <span>(323) 872-2181</span>
              </a>
              <div className="flex items-start space-x-3">
                <MapPin className="w-5 h-5 mt-1 flex-shrink-0" />
                <span>1764 E Vernon Ave<br />Los Angeles, CA 90058</span>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-4 text-[#FF6600]">Hours</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-300">Sunday:</span>
                <span>9 AM – 5 PM</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-300">Monday:</span>
                <span>9 AM – 6 PM</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-300">Tuesday:</span>
                <span>9 AM – 5 PM</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-300">Wednesday:</span>
                <span>9 AM – 6 PM</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-300">Thu - Fri:</span>
                <span>9 AM – 7 PM</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-300">Saturday:</span>
                <span>8 AM – 7 PM</span>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-4 text-[#FF6600]">Follow Us</h3>
            <div className="space-y-3">
              <a
                href="https://www.yelp.com/biz/vernon-window-tint-los-angeles-19"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center space-x-3 hover:text-[#FF6600] transition-colors"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/>
                </svg>
                <span>Review us on Yelp</span>
              </a>
              <a
                href="https://www.facebook.com/vernonwindowtint"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center space-x-3 hover:text-[#FF6600] transition-colors"
              >
                <Facebook className="w-5 h-5" />
                <span>Facebook.com/vernonwindowtint</span>
              </a>
            </div>
            <div className="mt-6">
              <a
                href="https://www.yelp.com/biz/vernon-window-tint-los-angeles-19"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block bg-[#FF6600] hover:bg-[#FF7722] px-6 py-3 rounded-lg font-semibold transition-colors"
              >
                Get a Quote on Yelp
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-8 text-center text-sm text-gray-400">
          <p>&copy; {new Date().getFullYear()} Vernon Window Tint. All rights reserved.</p>
          <p className="mt-2">Professional Window Tinting Services in Los Angeles</p>
        </div>
      </div>
    </footer>
  );
}
