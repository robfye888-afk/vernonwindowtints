import { useState } from 'react';
import { X } from 'lucide-react';

interface GalleryImage {
  id: number;
  url: string;
  title: string;
  category: string;
  before?: string;
}

export default function Gallery() {
  const [selectedImage, setSelectedImage] = useState<GalleryImage | null>(null);
  const [filter, setFilter] = useState<string>('all');

  const images: GalleryImage[] = [
    {
      id: 1,
      url: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800',
      title: 'Luxury Sedan Tinting',
      category: 'automotive',
    },
    {
      id: 2,
      url: 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=800',
      title: 'Sports Car Window Film',
      category: 'automotive',
    },
    {
      id: 3,
      url: 'https://images.unsplash.com/photo-1619405399517-d7fce0f13302?w=800',
      title: 'SUV Complete Tint',
      category: 'automotive',
    },
    {
      id: 4,
      url: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800',
      title: 'Modern Home Tinting',
      category: 'residential',
    },
    {
      id: 5,
      url: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800',
      title: 'Living Room Windows',
      category: 'residential',
    },
    {
      id: 6,
      url: 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=800',
      title: 'Bedroom Privacy Film',
      category: 'residential',
    },
    {
      id: 7,
      url: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=800',
      title: 'Office Building Tinting',
      category: 'commercial',
    },
    {
      id: 8,
      url: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800',
      title: 'Corporate Office Windows',
      category: 'commercial',
    },
    {
      id: 9,
      url: 'https://images.unsplash.com/photo-1497366811353-6870744d04b2?w=800',
      title: 'Retail Storefront Film',
      category: 'commercial',
    },
    {
      id: 10,
      url: 'https://images.unsplash.com/photo-1542362567-b07e54358753?w=800',
      title: 'Pickup Truck Tinting',
      category: 'automotive',
    },
    {
      id: 11,
      url: 'https://images.unsplash.com/photo-1449844908441-8829872d2607?w=800',
      title: 'Glass Door Residential',
      category: 'residential',
    },
    {
      id: 12,
      url: 'https://images.unsplash.com/photo-1497366754035-f200968a6e72?w=800',
      title: 'Conference Room Privacy',
      category: 'commercial',
    },
  ];

  const filteredImages = filter === 'all' ? images : images.filter(img => img.category === filter);

  return (
    <div className="min-h-screen bg-gray-50">
      <section className="bg-[#001F3F] text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold mb-4">Our Work</h1>
          <p className="text-xl text-gray-300">
            See the quality and precision of our window tinting installations
          </p>
        </div>
      </section>

      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            <button
              onClick={() => setFilter('all')}
              className={`px-6 py-3 rounded-lg font-semibold transition-colors ${
                filter === 'all'
                  ? 'bg-[#FF6600] text-white'
                  : 'bg-white text-[#001F3F] hover:bg-gray-100'
              }`}
            >
              All Work
            </button>
            <button
              onClick={() => setFilter('automotive')}
              className={`px-6 py-3 rounded-lg font-semibold transition-colors ${
                filter === 'automotive'
                  ? 'bg-[#FF6600] text-white'
                  : 'bg-white text-[#001F3F] hover:bg-gray-100'
              }`}
            >
              Automotive
            </button>
            <button
              onClick={() => setFilter('residential')}
              className={`px-6 py-3 rounded-lg font-semibold transition-colors ${
                filter === 'residential'
                  ? 'bg-[#FF6600] text-white'
                  : 'bg-white text-[#001F3F] hover:bg-gray-100'
              }`}
            >
              Residential
            </button>
            <button
              onClick={() => setFilter('commercial')}
              className={`px-6 py-3 rounded-lg font-semibold transition-colors ${
                filter === 'commercial'
                  ? 'bg-[#FF6600] text-white'
                  : 'bg-white text-[#001F3F] hover:bg-gray-100'
              }`}
            >
              Commercial
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredImages.map((image) => (
              <div
                key={image.id}
                className="group relative overflow-hidden rounded-lg shadow-lg cursor-pointer bg-white"
                onClick={() => setSelectedImage(image)}
              >
                <img
                  src={image.url}
                  alt={image.title}
                  className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#001F3F] via-transparent to-transparent opacity-0 group-hover:opacity-90 transition-opacity duration-300">
                  <div className="absolute bottom-0 left-0 right-0 p-6 text-white transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                    <h3 className="text-lg font-bold mb-1">{image.title}</h3>
                    <p className="text-sm text-gray-300 capitalize">{image.category}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredImages.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-600 text-lg">No images found for this category.</p>
            </div>
          )}
        </div>
      </section>

      {selectedImage && (
        <div
          className="fixed inset-0 bg-black bg-opacity-90 z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedImage(null)}
        >
          <button
            className="absolute top-4 right-4 text-white hover:text-[#FF6600] transition-colors"
            onClick={() => setSelectedImage(null)}
          >
            <X className="w-8 h-8" />
          </button>
          <div className="max-w-5xl w-full" onClick={(e) => e.stopPropagation()}>
            <img
              src={selectedImage.url}
              alt={selectedImage.title}
              className="w-full h-auto rounded-lg"
            />
            <div className="text-white mt-4 text-center">
              <h3 className="text-2xl font-bold mb-2">{selectedImage.title}</h3>
              <p className="text-gray-300 capitalize">{selectedImage.category} Tinting</p>
            </div>
          </div>
        </div>
      )}

      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-[#001F3F] mb-4">Want Your Project Featured?</h2>
          <p className="text-lg text-gray-700 mb-8">
            Get professional window tinting that you'll be proud to show off
          </p>
          <a
            href="https://www.yelp.com/biz/vernon-window-tint-los-angeles-19"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-[#FF6600] hover:bg-[#FF7722] text-white px-8 py-4 rounded-lg font-bold text-lg transition-colors"
          >
            Request a Quote
          </a>
        </div>
      </section>
    </div>
  );
}
