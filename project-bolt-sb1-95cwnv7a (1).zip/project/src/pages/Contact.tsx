import { Phone, MapPin, Clock, Mail, Facebook, ExternalLink } from 'lucide-react';

export default function Contact() {
  return (
    <div className="min-h-screen bg-gray-50">
      <section className="bg-[#001F3F] text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold mb-4">Contact Us</h1>
          <p className="text-xl text-gray-300">
            Get in touch for a free quote or to schedule your appointment
          </p>
        </div>
      </section>

      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <h2 className="text-3xl font-bold text-[#001F3F] mb-8">Get In Touch</h2>

              <div className="space-y-6 mb-8">
                <div className="flex items-start space-x-4 bg-white p-6 rounded-lg shadow-md">
                  <div className="bg-[#FF6600] p-3 rounded-lg">
                    <Phone className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-bold text-[#001F3F] mb-2">Phone</h3>
                    <a
                      href="tel:3238722181"
                      className="text-lg text-gray-700 hover:text-[#FF6600] transition-colors"
                    >
                      (323) 872-2181
                    </a>
                    <p className="text-sm text-gray-600 mt-1">Call us for immediate assistance</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4 bg-white p-6 rounded-lg shadow-md">
                  <div className="bg-[#FF6600] p-3 rounded-lg">
                    <MapPin className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-bold text-[#001F3F] mb-2">Address</h3>
                    <p className="text-gray-700">1764 E Vernon Ave</p>
                    <p className="text-gray-700">Los Angeles, CA 90058</p>
                    <a
                      href="https://www.google.com/maps/search/?api=1&query=1764+E+Vernon+Ave+Los+Angeles+CA+90058"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm text-[#FF6600] hover:text-[#FF7722] mt-2 inline-flex items-center space-x-1"
                    >
                      <span>Get Directions</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                </div>

                <div className="flex items-start space-x-4 bg-white p-6 rounded-lg shadow-md">
                  <div className="bg-[#FF6600] p-3 rounded-lg">
                    <Clock className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-[#001F3F] mb-3">Business Hours</h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Sunday:</span>
                        <span className="text-gray-700 font-medium">9 AM – 5 PM</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Monday:</span>
                        <span className="text-gray-700 font-medium">9 AM – 6 PM</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Tuesday:</span>
                        <span className="text-gray-700 font-medium">9 AM – 5 PM</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Wednesday:</span>
                        <span className="text-gray-700 font-medium">9 AM – 6 PM</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Thursday:</span>
                        <span className="text-gray-700 font-medium">9 AM – 7 PM</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Friday:</span>
                        <span className="text-gray-700 font-medium">9 AM – 7 PM</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Saturday:</span>
                        <span className="text-gray-700 font-medium">8 AM – 7 PM</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-[#001F3F] text-white p-8 rounded-lg">
                <h3 className="text-2xl font-bold mb-4">Follow Us Online</h3>
                <div className="space-y-4">
                  <a
                    href="https://www.yelp.com/biz/vernon-window-tint-los-angeles-19"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center space-x-3 hover:text-[#FF6600] transition-colors"
                  >
                    <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/>
                    </svg>
                    <span className="text-lg">Review us on Yelp</span>
                  </a>
                  <a
                    href="https://www.facebook.com/vernonwindowtint"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center space-x-3 hover:text-[#FF6600] transition-colors"
                  >
                    <Facebook className="w-6 h-6" />
                    <span className="text-lg">Facebook.com/vernonwindowtint</span>
                  </a>
                </div>
              </div>
            </div>

            <div>
              <h2 className="text-3xl font-bold text-[#001F3F] mb-8">Visit Our Location</h2>
              <div className="bg-white rounded-lg shadow-lg overflow-hidden mb-8">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3307.0982834769844!2d-118.24261!3d34.00362!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80c2c8e7b4d6d4d5%3A0x1234567890abcdef!2s1764%20E%20Vernon%20Ave%2C%20Los%20Angeles%2C%20CA%2090058!5e0!3m2!1sen!2sus!4v1234567890123!5m2!1sen!2sus"
                  width="100%"
                  height="450"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="Vernon Window Tint Location"
                />
              </div>

              <div className="bg-gradient-to-br from-[#001F3F] to-[#003366] text-white p-8 rounded-lg">
                <h3 className="text-2xl font-bold mb-4">Ready to Get Started?</h3>
                <p className="text-gray-200 mb-6">
                  Book your appointment on Yelp or give us a call. We're here to help with all your window tinting needs!
                </p>
                <div className="space-y-3">
                  <a
                    href="https://www.yelp.com/biz/vernon-window-tint-los-angeles-19"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block w-full bg-[#FF6600] hover:bg-[#FF7722] text-center px-6 py-4 rounded-lg font-bold text-lg transition-colors"
                  >
                    Book on Yelp
                  </a>
                  <a
                    href="tel:3238722181"
                    className="block w-full bg-white text-[#001F3F] hover:bg-gray-100 text-center px-6 py-4 rounded-lg font-bold text-lg transition-colors"
                  >
                    Call Now
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-[#001F3F] mb-4">Serving All of Los Angeles</h2>
          <p className="text-lg text-gray-700 leading-relaxed">
            Vernon Window Tint proudly serves customers throughout the greater Los Angeles area, including
            Downtown LA, East LA, South LA, Huntington Park, Bell, Maywood, Commerce, and surrounding communities.
            No matter where you are in LA, we're here to provide exceptional window tinting services.
          </p>
        </div>
      </section>
    </div>
  );
}
