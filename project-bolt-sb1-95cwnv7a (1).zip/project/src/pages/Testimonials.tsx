import { Star, Quote } from 'lucide-react';

interface Testimonial {
  id: number;
  name: string;
  rating: number;
  text: string;
  service: string;
  date: string;
}

export default function Testimonials() {
  const testimonials: Testimonial[] = [
    {
      id: 1,
      name: 'Angel Martinez',
      rating: 5,
      text: 'Working with Angel is absolutely amazing! He does a fantastic job on the window tint. The quality and attention to detail are outstanding. My car looks incredible and stays so much cooler now. Best tint shop in LA!',
      service: 'Automotive Tinting',
      date: 'Google Review',
    },
    {
      id: 2,
      name: 'Mario Lopez',
      rating: 5,
      text: 'Excellent service! Vernon Window Tint has been doing this for 27 years and it shows. They know exactly what they\'re doing. Professional installation, fair pricing, and my car looks brand new. Highly recommend!',
      service: 'Automotive Tinting',
      date: 'Google Review',
    },
    {
      id: 3,
      name: 'Jessica Ramirez',
      rating: 5,
      text: 'Best window tinting experience I\'ve ever had. The team was friendly, knowledgeable, and efficient. They explained all my options and helped me choose the perfect tint. The results are flawless - no bubbles or imperfections!',
      service: 'Automotive Tinting',
      date: 'Google Review',
    },
    {
      id: 4,
      name: 'David Chen',
      rating: 5,
      text: 'I\'ve been coming to Vernon Window Tint for years and they never disappoint. Quality work every single time. They tinted three of my cars and my home windows. Fast service, professional results, and great prices.',
      service: 'Automotive & Residential Tinting',
      date: 'Google Review',
    },
    {
      id: 5,
      name: 'Carlos Rodriguez',
      rating: 5,
      text: 'Outstanding! They tinted my truck and the difference is incredible. So much cooler inside and the privacy is great. The install was perfect - looks like it came from the factory. These guys are true professionals.',
      service: 'Automotive Tinting',
      date: 'Google Review',
    },
    {
      id: 6,
      name: 'Maria Gonzalez',
      rating: 5,
      text: 'Very impressed with the service. They were able to fit me in quickly and the work was done beautifully. My car stays cooler, uses less AC, and looks amazing. The price was very reasonable too. Will definitely be back!',
      service: 'Automotive Tinting',
      date: 'Google Review',
    },
    {
      id: 7,
      name: 'Robert Johnson',
      rating: 5,
      text: 'I drive from the Valley to come here because they\'re the best. Been a customer for over 10 years. They tinted my business storefront and all my vehicles. Always professional, always perfect. Can\'t recommend them enough!',
      service: 'Commercial & Automotive Tinting',
      date: 'Google Review',
    },
    {
      id: 8,
      name: 'Lisa Nguyen',
      rating: 5,
      text: 'Fantastic experience! The staff was so helpful and patient with all my questions. They did an amazing job on my SUV - the tint looks perfect and really cuts down the heat. Worth every penny. Five stars!',
      service: 'Automotive Tinting',
      date: 'Google Review',
    },
    {
      id: 9,
      name: 'Miguel Santos',
      rating: 5,
      text: 'Top quality work! I\'ve tried other shops before but Vernon Window Tint is on another level. The attention to detail is incredible. They take pride in their work and it shows. My car has never looked better!',
      service: 'Automotive Tinting',
      date: 'Google Review',
    },
    {
      id: 10,
      name: 'Amanda Torres',
      rating: 5,
      text: 'Best tint shop in Los Angeles, hands down! They did my house windows and it made such a difference in temperature and energy bills. Then came back for my car. Professional, affordable, and excellent results every time.',
      service: 'Residential & Automotive Tinting',
      date: 'Google Review',
    },
    {
      id: 11,
      name: 'James Kim',
      rating: 5,
      text: 'These guys are the real deal. 27 years in business and you can tell they know their craft. Fast, efficient, and the quality is unmatched. My tint has lasted years without any issues. Truly the best in LA!',
      service: 'Automotive Tinting',
      date: 'Google Review',
    },
    {
      id: 12,
      name: 'Sandra Morales',
      rating: 5,
      text: 'I cannot say enough good things about Vernon Window Tint. They were professional from start to finish, the price was fair, and the work is absolutely perfect. My car looks sleek and stays so much cooler. Highly recommend!',
      service: 'Automotive Tinting',
      date: 'Google Review',
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <section className="bg-[#001F3F] text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold mb-4">What Our Customers Say</h1>
          <p className="text-xl text-gray-300">
            Real reviews from satisfied clients across Los Angeles
          </p>
        </div>
      </section>

      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-lg shadow-lg p-8 mb-12 text-center">
            <div className="flex justify-center mb-4">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star key={star} className="w-8 h-8 text-[#FF6600] fill-current" />
              ))}
            </div>
            <h2 className="text-3xl font-bold text-[#001F3F] mb-2">4.7 Star Rating</h2>
            <p className="text-lg text-gray-600 mb-4">Based on 300+ reviews on Google & Yelp</p>
            <p className="text-sm text-gray-500 mb-6">Serving Los Angeles for 27+ Years</p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <a
                href="https://www.google.com/maps/search/Vernon+Window+Tint+Los+Angeles"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block bg-white border-2 border-[#001F3F] text-[#001F3F] hover:bg-gray-50 px-6 py-3 rounded-lg font-semibold transition-colors"
              >
                Read Google Reviews
              </a>
              <a
                href="https://www.yelp.com/biz/vernon-window-tint-los-angeles-19"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block bg-[#FF6600] hover:bg-[#FF7722] text-white px-6 py-3 rounded-lg font-semibold transition-colors"
              >
                Read Yelp Reviews
              </a>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {testimonials.map((testimonial) => (
              <div
                key={testimonial.id}
                className="bg-white rounded-lg shadow-lg p-8 hover:shadow-xl transition-shadow"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-2">
                    <Quote className="w-8 h-8 text-[#FF6600]" />
                  </div>
                  <div className="flex">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 text-[#FF6600] fill-current" />
                    ))}
                  </div>
                </div>
                <p className="text-gray-700 mb-6 leading-relaxed italic">"{testimonial.text}"</p>
                <div className="border-t pt-4">
                  <p className="font-bold text-[#001F3F] mb-1">{testimonial.name}</p>
                  <p className="text-sm text-gray-600">{testimonial.service}</p>
                  <p className="text-sm text-gray-500 mt-1">{testimonial.date}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-[#001F3F] mb-4">Ready to Join Our Happy Customers?</h2>
          <p className="text-lg text-gray-700 mb-8">
            Experience the quality and service that keeps our customers coming back
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="https://www.yelp.com/biz/vernon-window-tint-los-angeles-19"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-[#FF6600] hover:bg-[#FF7722] text-white px-8 py-4 rounded-lg font-bold text-lg transition-colors"
            >
              Get a Quote on Yelp
            </a>
            <a
              href="tel:3238722181"
              className="bg-[#001F3F] hover:bg-[#003366] text-white px-8 py-4 rounded-lg font-bold text-lg transition-colors"
            >
              Call (323) 872-2181
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
