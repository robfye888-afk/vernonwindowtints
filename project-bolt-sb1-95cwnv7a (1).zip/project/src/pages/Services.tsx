import { Car, Home, Building2, CheckCircle, ExternalLink } from 'lucide-react';

export default function Services() {
  return (
    <div className="min-h-screen bg-gray-50">
      <section className="bg-[#001F3F] text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold mb-4">Our Services</h1>
          <p className="text-xl text-gray-300">
            Premium window tinting solutions for every need
          </p>
        </div>
      </section>

      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
          <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-0">
              <div className="relative h-64 lg:h-auto">
                <img
                  src="https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=800"
                  alt="Automotive Window Tinting"
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-4 left-4 bg-[#FF6600] text-white px-4 py-2 rounded-lg flex items-center space-x-2">
                  <Car className="w-5 h-5" />
                  <span className="font-semibold">Automotive</span>
                </div>
              </div>
              <div className="p-8 lg:p-12">
                <h2 className="text-3xl font-bold text-[#001F3F] mb-4">Automotive Window Tinting</h2>
                <p className="text-gray-700 mb-6 leading-relaxed">
                  Enhance your vehicle's appearance, comfort, and protection with professional car window tinting.
                  Our high-quality films reduce heat, block UV rays, and add a sleek, stylish finish to any vehicle.
                </p>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-start space-x-3">
                    <CheckCircle className="w-6 h-6 text-[#FF6600] flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700">Protect your car interior from fading and sun damage</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <CheckCircle className="w-6 h-6 text-[#FF6600] flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700">Reduce glare for safer, more comfortable driving</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <CheckCircle className="w-6 h-6 text-[#FF6600] flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700">Keep your vehicle cooler and improve fuel efficiency</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <CheckCircle className="w-6 h-6 text-[#FF6600] flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700">Add privacy and security with premium tint shades</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <CheckCircle className="w-6 h-6 text-[#FF6600] flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700">California-compliant tinting options available</span>
                  </li>
                </ul>
                <a
                  href="https://www.yelp.com/biz/vernon-window-tint-los-angeles-19"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center space-x-2 bg-[#FF6600] hover:bg-[#FF7722] text-white px-6 py-3 rounded-lg font-semibold transition-colors"
                >
                  <span>Request Quote</span>
                  <ExternalLink className="w-4 h-4" />
                </a>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-0">
              <div className="relative h-64 lg:h-auto order-2 lg:order-1">
                <img
                  src="https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800"
                  alt="Residential Window Tinting"
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-4 left-4 bg-[#FF6600] text-white px-4 py-2 rounded-lg flex items-center space-x-2">
                  <Home className="w-5 h-5" />
                  <span className="font-semibold">Residential</span>
                </div>
              </div>
              <div className="p-8 lg:p-12 order-1 lg:order-2">
                <h2 className="text-3xl font-bold text-[#001F3F] mb-4">Residential Window Tinting</h2>
                <p className="text-gray-700 mb-6 leading-relaxed">
                  Transform your home with professional residential window film. Reduce energy costs, protect
                  your furniture from fading, and increase privacy while maintaining natural light and views.
                </p>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-start space-x-3">
                    <CheckCircle className="w-6 h-6 text-[#FF6600] flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700">Lower energy bills with heat-rejecting film technology</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <CheckCircle className="w-6 h-6 text-[#FF6600] flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700">Protect furniture, flooring, and artwork from UV damage</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <CheckCircle className="w-6 h-6 text-[#FF6600] flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700">Increase home comfort by reducing hot spots</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <CheckCircle className="w-6 h-6 text-[#FF6600] flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700">Enhance privacy without sacrificing natural light</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <CheckCircle className="w-6 h-6 text-[#FF6600] flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700">Multiple styles and shades to match your home</span>
                  </li>
                </ul>
                <a
                  href="https://www.yelp.com/biz/vernon-window-tint-los-angeles-19"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center space-x-2 bg-[#FF6600] hover:bg-[#FF7722] text-white px-6 py-3 rounded-lg font-semibold transition-colors"
                >
                  <span>Request Quote</span>
                  <ExternalLink className="w-4 h-4" />
                </a>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-0">
              <div className="relative h-64 lg:h-auto">
                <img
                  src="https://images.unsplash.com/photo-1497366216548-37526070297c?w=800"
                  alt="Commercial Window Tinting"
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-4 left-4 bg-[#FF6600] text-white px-4 py-2 rounded-lg flex items-center space-x-2">
                  <Building2 className="w-5 h-5" />
                  <span className="font-semibold">Commercial</span>
                </div>
              </div>
              <div className="p-8 lg:p-12">
                <h2 className="text-3xl font-bold text-[#001F3F] mb-4">Commercial Window Tinting</h2>
                <p className="text-gray-700 mb-6 leading-relaxed">
                  Improve your business environment with professional commercial window film. Reduce operating
                  costs, enhance employee comfort, and create a more professional appearance for your office or storefront.
                </p>
                <ul className="space-y-3 mb-8">
                  <li className="flex items-start space-x-3">
                    <CheckCircle className="w-6 h-6 text-[#FF6600] flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700">Significantly reduce cooling costs for your business</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <CheckCircle className="w-6 h-6 text-[#FF6600] flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700">Create a comfortable workspace by eliminating glare</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <CheckCircle className="w-6 h-6 text-[#FF6600] flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700">Enhance privacy for offices and conference rooms</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <CheckCircle className="w-6 h-6 text-[#FF6600] flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700">Improve building aesthetics with uniform appearance</span>
                  </li>
                  <li className="flex items-start space-x-3">
                    <CheckCircle className="w-6 h-6 text-[#FF6600] flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700">Professional installation with minimal business disruption</span>
                  </li>
                </ul>
                <a
                  href="https://www.yelp.com/biz/vernon-window-tint-los-angeles-19"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center space-x-2 bg-[#FF6600] hover:bg-[#FF7722] text-white px-6 py-3 rounded-lg font-semibold transition-colors"
                >
                  <span>Request Quote</span>
                  <ExternalLink className="w-4 h-4" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-[#001F3F] text-white">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Not Sure Which Service You Need?</h2>
          <p className="text-lg text-gray-300 mb-8">
            Contact us for a free consultation and we'll help you find the perfect tinting solution
          </p>
          <a
            href="tel:3238722181"
            className="inline-block bg-[#FF6600] hover:bg-[#FF7722] px-8 py-4 rounded-lg font-bold text-lg transition-colors"
          >
            Call (323) 872-2181
          </a>
        </div>
      </section>
    </div>
  );
}
