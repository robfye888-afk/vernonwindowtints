import { Phone, Shield, Sun, Eye, Zap, Star, Quote } from 'lucide-react';

export default function Home() {
  return (
    <div>
      <section className="relative h-[600px] flex items-center justify-center text-white">
        <div className="absolute inset-0 bg-gradient-to-r from-[#001F3F] via-[#002855] to-[#001F3F]">
          <div className="absolute inset-0 opacity-20" style={{
            backgroundImage: 'url("https://images.unsplash.com/photo-1619405399517-d7fce0f13302?w=1600")',
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }} />
        </div>
        <div className="relative z-10 max-w-4xl mx-auto px-4 text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
            Professional Window Tinting<br />in Los Angeles
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-gray-200">
            Trusted experts in automotive, residential, and commercial window tinting
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="https://www.yelp.com/biz/vernon-window-tint-los-angeles-19"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-[#FF6600] hover:bg-[#FF7722] px-8 py-4 rounded-lg font-bold text-lg transition-transform hover:scale-105 inline-flex items-center justify-center"
            >
              Get a Quote on Yelp
            </a>
            <a
              href="tel:3238722181"
              className="bg-white text-[#001F3F] hover:bg-gray-100 px-8 py-4 rounded-lg font-bold text-lg transition-transform hover:scale-105 inline-flex items-center justify-center space-x-2"
            >
              <Phone className="w-5 h-5" />
              <span>Call Now</span>
            </a>
            <a
              href="https://www.google.com/maps/search/Vernon+Window+Tint+Los+Angeles"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-white text-[#001F3F] hover:bg-gray-100 px-8 py-4 rounded-lg font-bold text-lg transition-transform hover:scale-105 inline-flex items-center justify-center space-x-2 border-2 border-white"
            >
              <Star className="w-5 h-5 fill-current" />
              <span>Google Reviews</span>
            </a>
          </div>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-[#001F3F] mb-4">About Vernon Window Tint</h2>
            <div className="w-24 h-1 bg-[#FF6600] mx-auto mb-6"></div>
            <p className="text-lg text-gray-700 max-w-3xl mx-auto leading-relaxed">
              Vernon Window Tint provides exceptional automotive, residential, and commercial window tinting
              services across Los Angeles. With years of experience and a commitment to quality, we're known
              for professional installation, premium materials, and outstanding customer service. Whether
              you're protecting your vehicle, home, or business, we deliver results that exceed expectations.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mt-12">
            <div className="text-center p-6 bg-gray-50 rounded-lg hover:shadow-lg transition-shadow">
              <div className="bg-[#FF6600] w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-[#001F3F] mb-2">UV Protection</h3>
              <p className="text-gray-600">Block up to 99% of harmful UV rays, protecting your skin and interiors</p>
            </div>

            <div className="text-center p-6 bg-gray-50 rounded-lg hover:shadow-lg transition-shadow">
              <div className="bg-[#FF6600] w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Eye className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-[#001F3F] mb-2">Privacy</h3>
              <p className="text-gray-600">Enhanced privacy for your vehicle, home, or office with stylish tint options</p>
            </div>

            <div className="text-center p-6 bg-gray-50 rounded-lg hover:shadow-lg transition-shadow">
              <div className="bg-[#FF6600] w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Sun className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-[#001F3F] mb-2">Glare Reduction</h3>
              <p className="text-gray-600">Reduce eye strain and improve visibility by eliminating harsh glare</p>
            </div>

            <div className="text-center p-6 bg-gray-50 rounded-lg hover:shadow-lg transition-shadow">
              <div className="bg-[#FF6600] w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Zap className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-[#001F3F] mb-2">Energy Efficiency</h3>
              <p className="text-gray-600">Lower cooling costs with heat-rejecting window film technology</p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-[#001F3F] mb-4">Featured Work</h2>
            <div className="w-24 h-1 bg-[#FF6600] mx-auto mb-6"></div>
            <p className="text-lg text-gray-700">Quality craftsmanship you can see and feel</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="relative overflow-hidden rounded-lg shadow-lg group">
              <img
                src="https://images.unsplash.com/photo-1552519507-da3b142c6e3d?w=600"
                alt="Automotive tinting"
                className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#001F3F] to-transparent opacity-70"></div>
              <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                <h3 className="text-xl font-bold mb-2">Automotive Tinting</h3>
                <p className="text-sm">Professional car window tinting</p>
              </div>
            </div>

            <div className="relative overflow-hidden rounded-lg shadow-lg group">
              <img
                src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=600"
                alt="Residential tinting"
                className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#001F3F] to-transparent opacity-70"></div>
              <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                <h3 className="text-xl font-bold mb-2">Residential Tinting</h3>
                <p className="text-sm">Home window film installation</p>
              </div>
            </div>

            <div className="relative overflow-hidden rounded-lg shadow-lg group">
              <img
                src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=600"
                alt="Commercial tinting"
                className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#001F3F] to-transparent opacity-70"></div>
              <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                <h3 className="text-xl font-bold mb-2">Commercial Tinting</h3>
                <p className="text-sm">Office and storefront solutions</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="flex justify-center mb-4">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star key={star} className="w-10 h-10 text-[#FF6600] fill-current" />
              ))}
            </div>
            <h2 className="text-4xl font-bold text-[#001F3F] mb-4">What Our Customers Say</h2>
            <div className="w-24 h-1 bg-[#FF6600] mx-auto mb-4"></div>
            <p className="text-xl text-gray-600 mb-2">4.7 Star Rating on Google</p>
            <p className="text-md text-gray-500">Based on 300+ reviews</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div className="bg-gray-50 rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <Quote className="w-8 h-8 text-[#FF6600]" />
                <div className="flex">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star key={star} className="w-4 h-4 text-[#FF6600] fill-current" />
                  ))}
                </div>
              </div>
              <p className="text-gray-700 mb-4 italic">"Working with Angel is absolutely amazing! He does a fantastic job on the window tint. The quality and attention to detail are outstanding. Best tint shop in LA!"</p>
              <div className="border-t pt-4">
                <p className="font-bold text-[#001F3F]">Angel Martinez</p>
                <p className="text-sm text-gray-500">Google Review</p>
              </div>
            </div>

            <div className="bg-gray-50 rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <Quote className="w-8 h-8 text-[#FF6600]" />
                <div className="flex">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star key={star} className="w-4 h-4 text-[#FF6600] fill-current" />
                  ))}
                </div>
              </div>
              <p className="text-gray-700 mb-4 italic">"Excellent service! Vernon Window Tint has been doing this for 27 years and it shows. Professional installation, fair pricing, and my car looks brand new. Highly recommend!"</p>
              <div className="border-t pt-4">
                <p className="font-bold text-[#001F3F]">Mario Lopez</p>
                <p className="text-sm text-gray-500">Google Review</p>
              </div>
            </div>

            <div className="bg-gray-50 rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <Quote className="w-8 h-8 text-[#FF6600]" />
                <div className="flex">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star key={star} className="w-4 h-4 text-[#FF6600] fill-current" />
                  ))}
                </div>
              </div>
              <p className="text-gray-700 mb-4 italic">"Best window tinting experience I've ever had. The team was friendly, knowledgeable, and efficient. The results are flawless - no bubbles or imperfections!"</p>
              <div className="border-t pt-4">
                <p className="font-bold text-[#001F3F]">Jessica Ramirez</p>
                <p className="text-sm text-gray-500">Google Review</p>
              </div>
            </div>
          </div>

          <div className="text-center">
            <a
              href="https://www.google.com/maps/search/Vernon+Window+Tint+Los+Angeles"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-2 bg-[#001F3F] hover:bg-[#003366] text-white px-8 py-4 rounded-lg font-bold text-lg transition-transform hover:scale-105"
            >
              <Star className="w-5 h-5 fill-current" />
              <span>Read More Google Reviews</span>
            </a>
          </div>
        </div>
      </section>

      <section className="py-16 bg-[#001F3F] text-white">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Get Started?</h2>
          <p className="text-xl mb-8 text-gray-300">
            Contact us today for a free quote and experience the Vernon Window Tint difference
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="https://www.yelp.com/biz/vernon-window-tint-los-angeles-19"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-[#FF6600] hover:bg-[#FF7722] px-8 py-4 rounded-lg font-bold text-lg transition-transform hover:scale-105"
            >
              Book on Yelp
            </a>
            <a
              href="tel:3238722181"
              className="bg-white text-[#001F3F] hover:bg-gray-100 px-8 py-4 rounded-lg font-bold text-lg transition-transform hover:scale-105 inline-flex items-center justify-center space-x-2"
            >
              <Phone className="w-5 h-5" />
              <span>(323) 872-2181</span>
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
