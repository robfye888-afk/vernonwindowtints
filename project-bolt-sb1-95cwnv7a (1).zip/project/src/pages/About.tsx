import { Award, Users, Clock, Target, CheckCircle } from 'lucide-react';

export default function About() {
  return (
    <div className="min-h-screen bg-gray-50">
      <section className="bg-[#001F3F] text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold mb-4">About Vernon Window Tint</h1>
          <p className="text-xl text-gray-300">
            Your trusted Los Angeles window tinting experts since day one
          </p>
        </div>
      </section>

      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
            <div>
              <h2 className="text-4xl font-bold text-[#001F3F] mb-6">
                Excellence in Window Tinting
              </h2>
              <div className="space-y-4 text-gray-700 leading-relaxed">
                <p>
                  Vernon Window Tint has become a cornerstone of the Los Angeles community, known for delivering
                  exceptional window tinting services to automotive, residential, and commercial clients throughout
                  the greater LA area.
                </p>
                <p>
                  Our journey began with a simple mission: to provide the highest quality window tinting services
                  with unmatched customer care. Today, we continue that tradition by combining years of expertise
                  with cutting-edge technology and premium materials.
                </p>
                <p>
                  What sets us apart is our unwavering commitment to precision, professionalism, and customer
                  satisfaction. Every project we undertake, whether it's tinting a single vehicle or outfitting
                  an entire office building, receives the same meticulous attention to detail and dedication to
                  excellence.
                </p>
                <p>
                  At Vernon Window Tint, we don't just apply film to windows—we enhance comfort, protect
                  investments, and improve the quality of life for our clients. Our experienced technicians
                  take pride in their craftsmanship, ensuring flawless installations that stand the test of time.
                </p>
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=800"
                alt="Professional team"
                className="rounded-lg shadow-xl w-full h-auto"
              />
              <div className="absolute -bottom-6 -right-6 bg-[#FF6600] text-white p-6 rounded-lg shadow-lg">
                <p className="text-3xl font-bold">15+</p>
                <p className="text-sm">Years Experience</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
            <div className="bg-white p-8 rounded-lg shadow-lg text-center">
              <div className="bg-[#FF6600] w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-[#001F3F] mb-2">Quality First</h3>
              <p className="text-gray-600">
                We use only premium materials and industry-leading techniques
              </p>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-lg text-center">
              <div className="bg-[#FF6600] w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-[#001F3F] mb-2">Expert Team</h3>
              <p className="text-gray-600">
                Skilled technicians with years of hands-on experience
              </p>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-lg text-center">
              <div className="bg-[#FF6600] w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-[#001F3F] mb-2">Timely Service</h3>
              <p className="text-gray-600">
                Efficient installations that respect your schedule
              </p>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-lg text-center">
              <div className="bg-[#FF6600] w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Target className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-[#001F3F] mb-2">Precision Work</h3>
              <p className="text-gray-600">
                Meticulous attention to detail on every project
              </p>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-lg p-8 lg:p-12">
            <h2 className="text-3xl font-bold text-[#001F3F] mb-8 text-center">Why Choose Vernon Window Tint?</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex items-start space-x-4">
                <CheckCircle className="w-6 h-6 text-[#FF6600] flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-bold text-[#001F3F] mb-2">Premium Materials</h3>
                  <p className="text-gray-600">
                    We exclusively use top-tier window films from trusted manufacturers, ensuring durability and performance.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <CheckCircle className="w-6 h-6 text-[#FF6600] flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-bold text-[#001F3F] mb-2">Expert Installation</h3>
                  <p className="text-gray-600">
                    Our certified technicians have mastered the art of flawless window tinting installation.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <CheckCircle className="w-6 h-6 text-[#FF6600] flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-bold text-[#001F3F] mb-2">Customer Satisfaction</h3>
                  <p className="text-gray-600">
                    We're not satisfied until you're delighted with the results. Your happiness is our priority.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <CheckCircle className="w-6 h-6 text-[#FF6600] flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-bold text-[#001F3F] mb-2">Competitive Pricing</h3>
                  <p className="text-gray-600">
                    Quality service doesn't have to break the bank. We offer fair, transparent pricing.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <CheckCircle className="w-6 h-6 text-[#FF6600] flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-bold text-[#001F3F] mb-2">Local Expertise</h3>
                  <p className="text-gray-600">
                    We understand LA's unique climate and regulations, ensuring compliant and effective solutions.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <CheckCircle className="w-6 h-6 text-[#FF6600] flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-bold text-[#001F3F] mb-2">Warranty Protection</h3>
                  <p className="text-gray-600">
                    All our work is backed by comprehensive warranties for your peace of mind.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-[#001F3F] text-white">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Experience the Vernon Window Tint Difference</h2>
          <p className="text-lg text-gray-300 mb-8">
            Join thousands of satisfied customers across Los Angeles who trust us with their window tinting needs
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="https://www.yelp.com/biz/vernon-window-tint-los-angeles-19"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-[#FF6600] hover:bg-[#FF7722] px-8 py-4 rounded-lg font-bold text-lg transition-colors"
            >
              Get a Quote on Yelp
            </a>
            <a
              href="tel:3238722181"
              className="bg-white text-[#001F3F] hover:bg-gray-100 px-8 py-4 rounded-lg font-bold text-lg transition-colors"
            >
              Call (323) 872-2181
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
